package in.Arpreet.Savya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SavyaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SavyaApplication.class, args);
	}

}
